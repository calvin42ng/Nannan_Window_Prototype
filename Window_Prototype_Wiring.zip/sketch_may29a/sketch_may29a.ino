const byte ECHO_PIN = 3;
const byte FAN_PINS[3] = {5, 6, 9};

const bool FAN_ACTIVE_HIGH = true;

const float MIN_CM = 9.0;
const float MAX_CM = 11.0;

const unsigned long TIMEOUT_MS = 500UL;

volatile unsigned long riseUs = 0;
volatile unsigned long pulseWidthUs = 0;
volatile unsigned long pulseSequence = 0;
volatile bool pulseStarted = false;

unsigned long lastSequence = 0;
unsigned long lastValidMs = 0;

bool hasValidReading = false;
bool fansOn = false;

void echoChanged() {
  unsigned long nowUs = micros();

  if (digitalRead(ECHO_PIN) == HIGH) {
    riseUs = nowUs;
    pulseStarted = true;
  } else if (pulseStarted) {
    pulseWidthUs = nowUs - riseUs;
    pulseSequence++;
    pulseStarted = false;
  }
}

void setFans(bool on) {
  byte level = FAN_ACTIVE_HIGH
    ? (on ? HIGH : LOW)
    : (on ? LOW : HIGH);

  for (byte i = 0; i < 3; i++) {
    digitalWrite(FAN_PINS[i], level);
  }

  if (fansOn != on) {
    Serial.println(on ? F("FANS ON") : F("FANS OFF"));
  }

  fansOn = on;
}

void setup() {
  for (byte i = 0; i < 3; i++) {
    digitalWrite(
      FAN_PINS[i],
      FAN_ACTIVE_HIGH ? LOW : HIGH
    );
    pinMode(FAN_PINS[i], OUTPUT);
  }

  pinMode(ECHO_PIN, INPUT);

  Serial.begin(115200);

  attachInterrupt(
    digitalPinToInterrupt(ECHO_PIN),
    echoChanged,
    CHANGE
  );

  Serial.println(F("Ready: 9-11 cm = all fans ON"));
  Serial.println(F("Outside range = all fans OFF"));
}

void loop() {
  unsigned long sequence;
  unsigned long widthUs;

  noInterrupts();
  sequence = pulseSequence;
  widthUs = pulseWidthUs;
  interrupts();

  if (sequence != lastSequence) {
    lastSequence = sequence;

    float cm = widthUs / 58.0;

    if (cm >= 2.0 && cm <= 400.0) {
      lastValidMs = millis();
      hasValidReading = true;

      bool inRange = (cm >= MIN_CM && cm <= MAX_CM);
      setFans(inRange);

      Serial.print(F("Distance: "));
      Serial.print(cm, 2);
      Serial.print(F(" cm | Fans: "));
      Serial.println(fansOn ? F("ON") : F("OFF"));
    } else {
      hasValidReading = false;
      setFans(false);
      Serial.println(F("Invalid distance: fans OFF"));
    }
  }

  if (!hasValidReading ||
      millis() - lastValidMs >= TIMEOUT_MS) {
    setFans(false);
  }
}